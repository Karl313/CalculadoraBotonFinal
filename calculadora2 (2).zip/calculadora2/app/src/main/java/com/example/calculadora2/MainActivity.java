package com.example.calculadora2;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

//declaramos los botones y los cajones textview
public class MainActivity extends AppCompatActivity {
    private Button b1;
    private Button b2;
    private Button b3;
    private Button b4;
    private Button b5;
    private Button b6;
    private Button b7;
    private Button b8;
    private Button b9;
    private Button b0;
    private Button bs;
    private Button br;
    private Button bm;
    private Button bd;
    private Button bi;
    private TextView operacion;
    private TextView resultado;
    private String simbolo = null;
    private String resul = "";
    private double num1;
    private double num2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//asignamos las vistas segun id
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        b4 = findViewById(R.id.b4);
        b5 = findViewById(R.id.b5);
        b6 = findViewById(R.id.b6);
        b7 = findViewById(R.id.b7);
        b8 = findViewById(R.id.b8);
        b9 = findViewById(R.id.b9);
        b0 = findViewById(R.id.b0);
        bs = findViewById(R.id.bs);
        br = findViewById(R.id.br);
        bm = findViewById(R.id.bm);
        bd = findViewById(R.id.bd);
        bi = findViewById(R.id.bi);
        operacion = findViewById(R.id.operacion);
        resultado = findViewById(R.id.resultado);

    }
//metodo de captura de pulsaciones
    public void capturaNum(View view) {
        //
        if (simbolo != null) {
            operacion.setText("");
            String pulsaciones = "";
            pulsaciones = operacion.getText().toString() + ((Button) view).getText().toString();
            operacion.setText(pulsaciones);


        } else {


            String pulsaciones = "";
            pulsaciones = operacion.getText().toString() + ((Button) view).getText().toString();
            operacion.setText(pulsaciones);
        }
        if (resultado.getText().toString().isEmpty() == false) {
            resultado.setText("");
        }
    }

    public void asignarOp(View view) {
        int idbutton = view.getId();
        String datoPantalla = operacion.getText().toString();
        num1 = Integer.parseInt(datoPantalla);

        switch (idbutton) {
            case R.id.bs:
                simbolo = "+";

                break;

            case R.id.br:
                simbolo = "-";
                break;

            case R.id.bm:
                simbolo = "*";
                break;
            case R.id.bd:
                simbolo = "/";
//asi

        }


        operacion.setText(datoPantalla + simbolo);


    }

    public void resultado(View view) {
        double resultado = 0;

        num2 = Integer.parseInt(operacion.getText().toString());

        operacion.setText("");

        switch (simbolo) {
            case "+":
                resultado = num1 + num2;
                break;
            case "-":
                resultado = num1 - num2;
                break;
            case "*":
                resultado = num1 * num2;
                break;
            case "/":
                resultado = num1 / num2;
                break;
        }
        this.resultado.setText(String.valueOf(resultado));
        simbolo = null;


    }
}






